#!/bin/bash

DB_PASS=$(hexdump -vn16 -e'4/4 "%08X" 1 "\n"' /dev/urandom);
SECRET_FLASK=$(hexdump -vn16 -e'4/4 "%08X" 1 "\n"' /dev/urandom);
SIGNING_KEY=$(hexdump -vn8 -e'4/4 "%08X" 1 "\n"' /dev/urandom);

if [[ ! -f ".env" ]]
then
    echo "DB_PASS=${DB_PASS}" > .env
    echo "SECRET_FLASK=${SECRET_FLASK}" >> .env
    echo "SIGNING_KEY=${SIGNING_KEY}" >> .env
fi

docker compose up --build --remove-orphans -d