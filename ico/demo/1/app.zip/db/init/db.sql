CREATE DATABASE notes_app;
USE notes_app;

CREATE TABLE users (
    id            INT            PRIMARY KEY AUTO_INCREMENT,
    username      VARCHAR(50)    NOT NULL UNIQUE,
    password      VARCHAR(50)    NOT NULL,
    uuid          VARCHAR(36)    NOT NULL,
    INDEX (username),
    INDEX (uuid)
);

CREATE TABLE notes (
    uuid          VARCHAR(36)    PRIMARY KEY,
    password      VARCHAR(50)    NOT NULL,
    user_uuid     VARCHAR(36)    NOT NULL,
    name          VARCHAR(50)    NOT NULL,
    description   TEXT,
    registered_at TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid)
      ON DELETE RESTRICT
      ON UPDATE CASCADE,
    UNIQUE KEY unique_note_name_per_user(user_uuid, name),
    INDEX (uuid)
);

CREATE TABLE friends (
    note_uuid   VARCHAR(36) NOT NULL,
    user_uuid   VARCHAR(36) NOT NULL,
    granted_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (note_uuid, user_uuid),
    FOREIGN KEY (note_uuid) REFERENCES notes(uuid)
      ON DELETE CASCADE
      ON UPDATE CASCADE,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid)
      ON DELETE CASCADE
      ON UPDATE CASCADE
);

CREATE TABLE comments (
    id          INT           PRIMARY KEY AUTO_INCREMENT,
    note_uuid   VARCHAR(36)   NOT NULL,
    friend_uuid VARCHAR(36)   NOT NULL,
    posted_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    comment     TEXT,
    FOREIGN KEY (note_uuid) REFERENCES notes(uuid)
      ON DELETE CASCADE
      ON UPDATE CASCADE,
    FOREIGN KEY (friend_uuid) REFERENCES users(uuid)
      ON DELETE RESTRICT
      ON UPDATE CASCADE,
    INDEX idx_posted_at (posted_at)
);

INSERT INTO users (username, password, uuid) VALUES
('test_user', 'f8e7d9e0f469186f4461e0b84c76a571', 'a74a5a24-c323-4661-a2cb-91138338eb5b');

INSERT INTO notes (uuid, password, user_uuid, name, description) VALUES
('11111111-1111-1111-1111-111111111111', 'f8e7d9e0f469186f4461e0b84c76a571', 'a74a5a24-c323-4661-a2cb-91138338eb5b', 'Note for flag 1', 'ICO{just_a_sanity_check_flag_for_you}');
