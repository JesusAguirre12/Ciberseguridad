from flask import current_app
        
class NotLoggedIn(Exception):
    pass

class WrongPassword(Exception):
    pass

class NotExistent(Exception):
    pass