from flask import Blueprint, jsonify, request, render_template, url_for
from .utils import *

frontend = Blueprint('frontend', 'frontend')

@frontend.get('/')
def index():

    return render_template('index.html', notes = get_all_notes())

@frontend.get('/login')
@not_logged
def login_page():
    return render_template('login.html')

@frontend.post('/login')
@not_logged
def login():
    username = request.form.get('username', False)
    password = request.form.get('password', False)

    if not all((username, password)):
        flash('You need to provide username and password')
        return redirect(url_for('frontend.register'))

    try:
        user_id = login_user(username, password)
    except WrongPassword:
        flash('Wrong username or password')
        return redirect(url_for('frontend.login'))

    session['username'] = username
    session['user_id'] = user_id
    flash('Success')
    return redirect(url_for('frontend.index'))

@frontend.get('/logout')
@logged
def logout():
    del session['username']
    del session['user_id']
    return redirect(url_for('frontend.index')) 

@frontend.get('/register')
@not_logged
def register_page():
    return render_template('register.html')

@frontend.post('/register')
@not_logged
def register():
    username = request.form.get('username', False).replace('\'','').replace('\\','')
    password = request.form.get('password', False)
    
    if not all((username, password)):
        flash('You need to provide username and password')
        return redirect(url_for('frontend.register'))
    
    if len(username) < 8 or len(password) < 8:
        flash('Username or password too short')
        return redirect(url_for('frontend.register'))

    if len(username) > 30 or len(password) > 30:
        flash('Username or password too long')
        return redirect(url_for('frontend.register'))

    user_id = register_user(username, password)

    if not user_id:
        flash('User already registered')
        return redirect(url_for('frontend.register'))
    
    session['username'] = username
    session['user_id'] = user_id
    return redirect(url_for('frontend.index'))

@frontend.get('/add_note')
@logged
def add_note_page():
    return render_template('add_note.html')

@frontend.post('/add_note')
@logged
def add_note():
    name = request.form.get('name', False)
    desc = request.form.get('desc', False)

    if not all((name, desc)):
        flash('You need to provide a name and a content!')
        return redirect(url_for('frontend.add_note'))
    
    note_id, note_password = create_note(session['user_id'], name, desc)

    if not note_id:
        flash('Failed to add note')
        return redirect(url_for('frontend.list_notes_page'))

    flash(f'Note {note_id} added correctly! You can use {note_password} to share the access to it. Remember it as you will not see it again :)')
    return redirect(url_for('frontend.add_note'))

@frontend.get('/list_notes')
@logged
def list_notes_page():
    user_id = session['user_id']
    notes = get_notes_by_user(user_id)

    if not notes:
        flash('You didn\'t add any note yet!')

    return render_template('list_notes.html', notes = notes)

@frontend.get('/view/<uuid_str>')
@logged
def view_note_by_uuid(uuid_str):
    note = get_note_by_id(uuid_str)
    friends = get_friends_by_note_id(uuid_str)
    comments = get_comments_by_note_id(uuid_str)

    if not note:
        flash('This note does not exist!')
        return render_template('index.html')
    
    return render_template('view_note.html', note = note, friends = friends, comments = comments, token_access = False)

@frontend.post('/add_friend/<uuid_str>')
@logged
def add_friend(uuid_str):
    password = request.form.get('password', False)

    note = get_note_by_id(uuid_str)

    if not note:
        flash('This note does not exist!')
        return render_template('index.html')

    if not password:
        flash('You need to specify the password to add a friend to this note')
        return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))
    
    res = add_friend_to_note(uuid_str, password, session['user_id'])

    if not res:
        flash('Cannot add friend to note (possibly the user owns the note or is already a friend)')
    else:
        flash('Friend added successfully')
    return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))

@frontend.post('/add_comment/<uuid_str>')
@logged
def add_comment(uuid_str):
    user_id = session['user_id']
    friends = get_friends_by_note_id(uuid_str)

    if user_id not in [f['user_uuid'] for f in friends]:
        flash('You are not authorized to add a comment.')
        return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))
    
    comment = request.form.get('comment', False)

    if not comment:
        flash('You need to specify a comment')
        return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))

    res = add_comment_to_note(uuid_str, user_id, comment)

    if not res:
        flash('An error occurred')
    else:
        flash('Comment added successfully')
    return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))

@frontend.post('/share/<uuid_str>')
@logged
def create_sharing_token(uuid_str):
    user_id = session['user_id']
    note = get_note_by_id(uuid_str)

    if not note or note['user_uuid'] != user_id:
        flash('This note does not exist or you are not the owner!')
        return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))

    owner_username = get_username_by_user_id(note['user_uuid'])
    token = generate_sharing_token(owner_username, uuid_str)

    if not token:
        flash('Can\'t generate token')
        return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))
    
    flash(f'Here is your token: {token}')
    return redirect(url_for('frontend.view_note_by_uuid', uuid_str = uuid_str))

@frontend.get('/use_token')
@logged
def use_token_page():
    return render_template('token.html')

@frontend.post('/view_by_token') 
@logged
def view_by_token():
    token = request.form.get('token', False)

    if not token:
        flash('Invalid token')
        return render_template('index.html')

    uuid_str = verify_token(token)

    if not uuid_str:
        flash('This note does not exist!')
        return render_template('index.html')

    note = get_note_by_id(uuid_str)
    friends = get_friends_by_note_id(uuid_str)
    comments = get_comments_by_note_id(uuid_str)

    if not note:
        flash('This note does not exist!')
        return render_template('index.html')
    
    flash('Access granted via token')

    return render_template('view_note.html', note = note, friends = friends, comments = comments, token_access = True)
