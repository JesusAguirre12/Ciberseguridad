from functools import wraps
from flask import flash, redirect, url_for, session, g
import os
import hashlib
from .exceptions import *
import uuid
from base64 import b64encode, b64decode
from hashlib import md5
from Crypto.Hash import Poly1305
from Crypto.Util.Padding import pad

USERNAME_TOKEN_SIZE = 30
UUID_TOKEN_SIZE = 36

def xor(a,b):
    return bytes([x^y for x,y in zip(a,b)])

def execute_query(query, params, commit=False):
    cursor = g.mysql.connection.cursor()
    cursor.execute(query, params)

    if commit:
        g.mysql.connection.commit()
    result = cursor.fetchall()
    insertObject = []
    try:
        columnNames = [column[0] for column in cursor.description]

        for record in result:
            insertObject.append(dict(zip(columnNames, record)))
    except TypeError:
        return None
    finally:
        cursor.close()
    return insertObject

def is_logged():
    return 'username' in session

def logged(func):
    @wraps(func)
    def f(*args, **argv):
        if not is_logged():
            flash('You need to sign-in first!')
            return redirect(url_for('frontend.login_page'))

        return func(*args, **argv)
    return f

def not_logged(func):
    @wraps(func)
    def f(*args, **argv):
        if is_logged():
            return redirect(url_for('frontend.index'))
        return func(*args, **argv)
    return f

def login_user(username, password):
    query = 'SELECT uuid FROM users WHERE username = %s AND password = %s'
    password_hash = hashlib.md5(password.encode()).hexdigest()
    result = execute_query(query, [username, password_hash])

    if len(result) < 1:
        raise WrongPassword()

    return result[0]['uuid']

def register_user(username, password):
    check_user_exists = 'SELECT id FROM users WHERE username = %s'
    if len(execute_query(check_user_exists, [username])) > 0:
        return False
    query = 'INSERT INTO users (username,password,uuid) VALUES (%s, %s, %s)'
    password_hash = hashlib.md5(password.encode()).hexdigest()
    user_id = str(uuid.uuid4())
    try:
        execute_query(query, [username, password_hash, user_id], commit=True)
    except Exception as e:
        return False
    return user_id

def get_username_by_user_id(user_id):
    query = 'SELECT username FROM users WHERE uuid = %s'
    result = execute_query(query, [user_id])

    if len(result) < 1:
        return False

    return result[0]['username']

def create_note(user_id, name, desc, password_base = os.urandom(8)):
    check_user_exists = 'SELECT id FROM users WHERE uuid = %s'
    
    if len(execute_query(check_user_exists, [user_id])) == 0:
        return False, False
    
    password = b64encode(xor(xor(password_base, pad(name.encode(), 8)[:8]), hashlib.md5(desc.encode()).digest())).decode().strip('=')
    password_hash = hashlib.md5(password.encode()).hexdigest()
    note_id = str(uuid.uuid4())

    query1 = 'INSERT INTO notes (uuid, password, user_uuid, name, description) VALUES (%s, %s, %s, %s, %s)'
    query2 = 'INSERT INTO friends (note_uuid, user_uuid) VALUES (%s, %s)'
    try:
        execute_query(query1, [note_id, password_hash, user_id, name, desc], commit=True)
        execute_query(query2, [note_id, user_id], commit=True)
    except Exception as e:
        return False, False
    return note_id, password

def get_note_by_id(uuid_str):
    query = 'SELECT * FROM notes WHERE uuid = %s'
    result = execute_query(query, [uuid_str])

    if len(result) < 1:
        raise NotExistent()

    return result[0]

def get_notes_by_user(user_id):
    check_user_exists = 'SELECT id FROM users WHERE uuid = %s'
    
    if len(execute_query(check_user_exists, [user_id])) == 0:
        return False, False

    query = """SELECT
                a.*
                FROM
                notes AS a
                JOIN friends AS f
                    ON a.uuid = f.note_uuid
                WHERE
                f.user_uuid = %s;
            """
    result = execute_query(query, [user_id])

    if len(result) < 1:
        return False

    return result

def get_all_notes():
    query = 'SELECT * FROM notes'
    result = execute_query(query, [])

    if len(result) < 1:
        return False

    return result

def get_friends_by_note_id(uuid_str):
    query = 'SELECT user_uuid FROM friends WHERE note_uuid = %s'
    result = execute_query(query, [uuid_str])
    return result

def get_comments_by_note_id(uuid_str):
    query = """
        SELECT s.*, u.username AS friend_name
        FROM comments s
        JOIN users u ON s.friend_uuid = u.uuid
        WHERE s.note_uuid = %s
        ORDER BY s.id ASC LIMIT 10
    """
    result = execute_query(query, [uuid_str])
    return result

def add_friend_to_note(note_uuid, password, user_id):
    query = 'SELECT uuid FROM notes WHERE uuid = %s AND password = %s'
    password_hash = hashlib.md5(password.encode()).hexdigest()
    result = execute_query(query, [note_uuid, password_hash])

    if len(result) < 1:
        return False
    
    query = 'INSERT INTO friends (note_uuid, user_uuid) VALUES (%s, %s)'
    try:
        execute_query(query, [note_uuid, user_id], commit=True)
    except Exception as e:
        return False
    return True
    
def add_comment_to_note(note_uuid, user_id, comment):
    query = 'INSERT INTO comments (note_uuid, friend_uuid, comment) VALUES (%s, %s, %s)'
    try:
        execute_query(query, [note_uuid, user_id, comment], commit=True)
    except Exception as e:
        return False
    return True

def generate_sharing_token(username, uuid_str):
    try:
        if isinstance(username, str):
            username = username.encode()

        if isinstance(uuid_str, str):
            uuid_str = uuid_str.encode()

        if len(uuid_str) != UUID_TOKEN_SIZE:
            return False

        data = username[:USERNAME_TOKEN_SIZE].ljust(USERNAME_TOKEN_SIZE, b'\x00') + uuid_str
        hashed = md5(data).digest()
        nonce = os.urandom(16)
        key = os.environ.get('SIGNINGKEY', 'A'*16)

        if isinstance(key, str):
            key = key.encode()

        tag = Poly1305.Poly1305_MAC(key, nonce, hashed).digest()

        return b64encode(nonce+data+tag).decode()
    except:
        return False
    
def verify_token(token):
    try:
        key = os.environ.get('SIGNINGKEY', 'A'*16)

        if isinstance(token, str):
            token = token.encode()

        if isinstance(key, str):
            key = key.encode()
        
        decoded_token = b64decode(token)
        nonce = decoded_token[:16]
        data = decoded_token[16:16+USERNAME_TOKEN_SIZE+UUID_TOKEN_SIZE]
        tag = decoded_token[16+USERNAME_TOKEN_SIZE+UUID_TOKEN_SIZE:]

        hashed = md5(data).digest()
        assert tag == Poly1305.Poly1305_MAC(key, nonce, hashed).digest()

        token_username = data[:USERNAME_TOKEN_SIZE].rstrip(b'\x00').decode()
        uuid_str = data[USERNAME_TOKEN_SIZE:].decode()
        note = get_note_by_id(uuid_str)
        owner_username = get_username_by_user_id(note['user_uuid'])

        if token_username != owner_username:
            return False

        return uuid_str
    except Exception as e:
        return False
